import json
import boto3
from sqlalchemy import create_engine

def lambda_handler(event, context):
    
    client = boto3.client('datapipeline')
    pipelines = client.list_pipelines()['pipelineIdList']
    
    for pipeline in pipelines:
        if pipeline['name'] == 'pipeline3':
            id = pipeline['id']
            # response = client.activate_pipeline(pipelineId=id)

    engine = create_engine(f'postgresql://{config["redshift"]["username"]}:{config["redshift"]["password"]}@redshift-cluster.cy8zz3a1tpnj.us-east-1.redshift.amazonaws.com:5439/dev')

    with engine.connect() as connection:
        query = '''
        
        '''
        result = connection.execute(query)
            
    
    return id